package com.glitch.detectivesearch;


public interface ListItemClickListener {
    void onListItemClick(int clickedItemIndex);
}
